<?php
require_once __DIR__ . '/helpers.php';
function page_header(string $title): void {
    $u = current_user();
    $flash = take_flash();
    $home = (basename($_SERVER['SCRIPT_NAME'] ?? '') === 'index.php');
    ?><!doctype html>
    <html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title) ?> · <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= e(url('assets/style.css')) ?>?v=<?= (int) @filemtime(__DIR__ . '/../public/assets/style.css') ?>">
    <script defer src="<?= e(url('assets/app.js')) ?>"></script>
    </head><body class="<?= $home ? 'home-page' : 'inner-page' ?>">
    <header class="topbar">
      <a class="brand" href="<?= e(url()) ?>" aria-label="FoodRescue Bangladesh home"><span class="brand-mark" aria-hidden="true"><svg viewBox="0 0 48 48"><path d="M24 41C9 33 4 22 10 13c4-6 11-5 14 1 3-6 10-7 14-1 6 9 1 20-14 28Z" fill="currentColor"/><path d="M14 29c7-1 12 1 16 6M24 34c0-8 4-13 11-17" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round"/><path d="M15 18c2-3 5-3 7 0-2 4-5 4-7 0Z" fill="#fff"/></svg></span><span class="brand-text"><strong>FoodRescue</strong><small>Bangladesh</small><span class="brand-tagline">Save Food · Feed People · Build a Better Tomorrow</span></span></a>
      <nav class="nav home-nav" aria-label="Main navigation">
        <a class="nav-home" href="<?= e(url()) ?>"><span>⌂</span> Home</a>
        <a href="<?= e(url('food.php')) ?>">Available Food</a>
        <?php if ($u): ?>
          <a class="role-nav-link" href="<?= e(url('dashboard.php')) ?>">My Dashboard</a>
          <?php if (in_array($u['role'], ['restaurant','event_organizer'], true)): ?>
            <a class="role-nav-link" href="<?= e(url('food_create.php')) ?>">＋ Donate Food</a>
            <a class="role-nav-link" href="<?= e(url('my_food.php')) ?>">My Listings</a>
            <a class="role-nav-link" href="<?= e(url('requests.php')) ?>">Requests</a>
          <?php elseif (in_array($u['role'], ['ngo','demand_reporter'], true)): ?>
            <a class="role-nav-link" href="<?= e(url('food.php')) ?>">Find Food</a>
            <a class="role-nav-link" href="<?= e(url('demand_create.php')) ?>">Report Need</a>
            <a class="role-nav-link" href="<?= e(url('requests.php')) ?>">My Requests</a>
          <?php elseif ($u['role'] === 'volunteer'): ?>
            <a class="role-nav-link" href="<?= e(url('volunteer.php')) ?>">Rescue Tasks</a>
            <a class="role-nav-link" href="<?= e(url('deliveries.php')) ?>">My Deliveries</a>
          <?php elseif ($u['role'] === 'admin'): ?>
            <a class="role-nav-link" href="<?= e(url('admin.php')) ?>">Admin Panel</a>
            <a class="role-nav-link" href="<?= e(url('admin_users.php')) ?>">Users</a>
            <a class="role-nav-link" href="<?= e(url('reports.php')) ?>">Reports</a>
          <?php endif; ?>
        <?php else: ?>
          <a href="<?= e(url('login.php')) ?>">Log in</a>
          <a href="<?= e(url('register.php')) ?>">Join FoodRescue</a>
        <?php endif; ?>
      </nav>
      <div class="header-actions"><div class="language-switch" role="group" aria-label="Language"><button type="button" class="lang-btn" data-lang="bn">বাংলা</button><button type="button" class="lang-btn active" data-lang="en">English</button></div><button type="button" class="theme-toggle" id="themeToggle" aria-label="Toggle dark mode" title="Toggle theme">☼</button>
        <details class="user-menu"><summary><span class="user-avatar">♙</span><span class="hello-user"><?= $u ? e($u['name']) : 'Hello, User' ?></span><span class="user-caret">⌄</span></summary><div class="user-dropdown"><?php if ($u): ?><a href="<?= e(url('dashboard.php')) ?>">Dashboard</a><a href="<?= e(url('profile.php')) ?>">Profile</a><a href="<?= e(url('notifications.php')) ?>">Notifications</a><?php if ($u['role']==='admin'): ?><a href="<?= e(url('admin.php')) ?>">Admin panel</a><a href="<?= e(url('admin_users.php')) ?>">Manage users</a><?php endif; ?><form method="post" action="<?= e(url('logout.php')) ?>"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><button type="submit">Log out</button></form><?php else: ?><a href="<?= e(url('login.php')) ?>">Log in</a><a href="<?= e(url('register.php')) ?>">Create account</a><?php endif; ?><button type="button" id="banglishToggle" class="banglish-menu-toggle">বাংলা টাইপিং: চালু</button></div></details>
      </div>
    </header><main class="container">
    <?php if ($flash): ?><div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif;
}
function page_footer(): void {
    ?></main><footer class="footer"><div><strong>FoodRescue Bangladesh</strong><p>Rescue surplus food. Connect communities. Reduce waste.</p></div><div>Designed for Bangladesh · Currency: BDT (৳) · Time zone: Asia/Dhaka</div></footer></body></html><?php
}
