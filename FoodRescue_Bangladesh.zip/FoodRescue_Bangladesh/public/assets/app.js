document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-confirm]').forEach(el => {
    el.addEventListener('click', e => {
      if (!window.confirm(el.getAttribute('data-confirm') || 'Are you sure?')) e.preventDefault();
    });
  });
  document.querySelectorAll('input[type="datetime-local"]').forEach(el => {
    // Keep browser-native local datetime controls; server stores Asia/Dhaka wall time.
  });
});

// Browser-based one-time GPS capture: location is only read after the user clicks.
document.querySelectorAll('[data-geolocate]').forEach((button) => {
  button.addEventListener('click', () => {
    const form = button.closest('form');
    const lat = form?.querySelector('[name="gps_lat"]');
    const lng = form?.querySelector('[name="gps_lng"]');
    if (!navigator.geolocation) { alert('Geolocation is not supported by this browser.'); return; }
    button.disabled = true; button.textContent = 'Getting location…';
    navigator.geolocation.getCurrentPosition((position) => {
      if (lat) lat.value = position.coords.latitude.toFixed(7);
      if (lng) lng.value = position.coords.longitude.toFixed(7);
      button.disabled = false; button.textContent = 'GPS location captured';
    }, (error) => {
      button.disabled = false; button.textContent = 'Use my current GPS location';
      alert(error.message || 'Could not access location. Allow location permission and try again.');
    }, { enableHighAccuracy: true, timeout: 12000, maximumAge: 30000 });
  });
});


// Optional local Banglish typing helper. It runs only in ordinary text fields;
// passwords, email addresses, URLs, phone numbers, dates and numeric fields are untouched.
(() => {
  const KEY = 'foodrescue-banglish-enabled';
  const common = {
    ami:'আমি', amra:'আমরা', amar:'আমার', apni:'আপনি', tumi:'তুমি', tomar:'তোমার', tomra:'তোমরা',
    valo:'ভালো', bhalo:'ভালো', khub:'খুব', achi:'আছি', acho:'আছো', ache:'আছে', ase:'আছে', nai:'নাই', nei:'নেই',
    ki:'কি', keno:'কেন', kivabe:'কিভাবে', kibhabe:'কিভাবে', kothay:'কোথায়', kokhon:'কখন', ke:'কে', kar:'কার',
    amar:'আমার', apnar:'আপনার', dhonnobad:'ধন্যবাদ', assalamu:'আসসালামু', alaikum:'আলাইকুম', salam:'সালাম',
    bangla:'বাংলা', bangladesh:'বাংলাদেশ', dhaka:'ঢাকা', khabar:'খাবার', khabo:'খাবো', khay:'খায়', pani:'পানি',
    food:'ফুড', rescue:'রেসকিউ', donation:'ডোনেশন', donate:'ডোনেট', restaurant:'রেস্টুরেন্ট', ngo:'এনজিও',
    dorkar:'দরকার', lagbe:'লাগবে', chai:'চাই', hobe:'হবে', korbo:'করবো', korun:'করুন', koro:'করো',
    korte:'করতে', kore:'করে', korchi:'করছি', hocche:'হচ্ছে', hoy:'হয়', hoye:'হয়ে', diye:'দিয়ে', den:'দেন', dao:'দাও',
    naam:'নাম', nam:'নাম', thikana:'ঠিকানা', elaka:'এলাকা', jela:'জেলা', phone:'ফোন', email:'ইমেইল',
    dhonnobad:'ধন্যবাদ', shob:'সব', sob:'সব', user:'ইউজার', notun:'নতুন', account:'অ্যাকাউন্ট', login:'লগইন', register:'রেজিস্টার',
    aj:'আজ', kal:'কাল', agami:'আগামী', ekhon:'এখন', pore:'পরে', sokal:'সকাল', dupur:'দুপুর', rat:'রাত',
    manush:'মানুষ', jonno:'জন্য', theke:'থেকে', sathe:'সাথে', ebong:'এবং', kintu:'কিন্তু', jodi:'যদি', tahole:'তাহলে',
    bari:'বাড়ি', poribar:'পরিবার', bondhu:'বন্ধু', kaj:'কাজ', project:'প্রজেক্ট', website:'ওয়েবসাইট',
    help:'হেল্প', sahajjo:'সাহায্য', proyojon:'প্রয়োজন', shundor:'সুন্দর', sundor:'সুন্দর', bhalo:'ভালো', valo:'ভালো',
    ha:'হ্যাঁ', hya:'হ্যাঁ', na:'না', thik:'ঠিক', thikache:'ঠিক আছে', jani:'জানি', janina:'জানি না',
    nam:'নাম', bari:'বাড়ি'
  };
  // Phonetic fallback for words not in the common-word dictionary.
  const rules = [
    [/ksh/g,'ক্ষ'],[/kkh/g,'ক্ষ'],[/ng/g,'ং'],[/chh/g,'ছ'],[/shch/g,'শ্চ'],[/kh/g,'খ'],[/gh/g,'ঘ'],[/ch/g,'চ'],[/jh/g,'ঝ'],[/th/g,'থ'],[/dh/g,'ধ'],[/ph/g,'ফ'],[/bh/g,'ভ'],[/sh/g,'শ'],[/ss/g,'স'],[/rr/g,'ড়'],[/ng/g,'ঙ'],[/ny/g,'ন্য'],[/oi/g,'ৈ'],[/ou/g,'ৌ'],[/ow/g,'ও'],[/aa/g,'া'],[/ee/g,'ী'],[/ii/g,'ী'],[/oo/g,'ূ'],[/uu/g,'ু'],[/ri/g,'ৃ'],[/a/g,'া'],[/i/g,'ি'],[/e/g,'ে'],[/u/g,'ু'],[/o/g,'ো'],[/k/g,'ক'],[/g/g,'গ'],[/c/g,'চ'],[/j/g,'জ'],[/t/g,'ত'],[/d/g,'দ'],[/n/g,'ন'],[/p/g,'প'],[/f/g,'ফ'],[/b/g,'ব'],[/m/g,'ম'],[/r/g,'র'],[/l/g,'ল'],[/s/g,'স'],[/h/g,'হ'],[/y/g,'য়'],[/w/g,'ও'],[/v/g,'ভ'],[/x/g,'ক্স'],[/z/g,'জ']
  ];
  function transliterate(word) {
    const lower = word.toLowerCase();
    if (common[lower]) return common[lower];
    let out = lower;
    for (const [pattern, replacement] of rules) out = out.replace(pattern, replacement);
    return out;
  }
  function enabled() { try { return localStorage.getItem(KEY) !== 'false'; } catch (_) { return true; } }
  function saveEnabled(value) { try { localStorage.setItem(KEY, value ? 'true' : 'false'); } catch (_) { /* Storage can be disabled; current-page toggle still works. */ } }
  function refreshToggle() {
    const btn = document.getElementById('banglishToggle');
    if (!btn) return;
    btn.textContent = enabled() ? 'বাংলা টাইপিং: চালু' : 'বাংলা টাইপিং: বন্ধ';
    btn.setAttribute('aria-pressed', String(enabled()));
    btn.title = enabled() ? 'Banglish লিখে Space চাপলে বাংলা হবে; English রাখতে toggle বন্ধ করুন' : 'Banglish-to-Bangla typing চালু করুন';
  }
  document.addEventListener('DOMContentLoaded', () => {
    const btn = document.getElementById('banglishToggle');
    if (btn) btn.addEventListener('click', () => { saveEnabled(!enabled()); btn.dataset.pageEnabled = String(!enabled()); refreshToggle(); });
    refreshToggle();
    const eligible = el => {
      if (!(el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement)) return false;
      if (el instanceof HTMLTextAreaElement) return !el.disabled && !el.readOnly && !el.hasAttribute('data-no-banglish');
      const type = (el.type || 'text').toLowerCase();
      return ['text','search'].includes(type) && !el.disabled && !el.readOnly && !el.hasAttribute('data-no-banglish') && !/email|password|username|user_name|phone|mobile|url|slug|code|token|otp|district_code/i.test((el.name || '') + ' ' + (el.autocomplete || ''));
    };
    document.addEventListener('keydown', event => {
      const el = event.target;
      if (!enabled() || !eligible(el) || event.key !== ' ' || event.ctrlKey || event.metaKey || event.altKey) return;
      const start = el.selectionStart, end = el.selectionEnd;
      if (start == null || start !== end || start === 0) return;
      const before = el.value.slice(0, start);
      const match = before.match(/([A-Za-z]+)$/);
      if (!match) return;
      const word = match[1];
      const converted = transliterate(word);
      if (converted === word) return;
      event.preventDefault();
      const from = start - word.length;
      el.setRangeText(converted + ' ', from, end, 'end');
      el.dispatchEvent(new Event('input', {bubbles:true}));
    });
  });
})();

// Theme toggle for the redesigned homepage and shared navigation.
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('themeToggle');
  if (!toggle) return;
  let dark = false;
  try { dark = localStorage.getItem('foodrescue-theme') === 'dark'; } catch (_) {}
  const applyTheme = () => { document.body.classList.toggle('dark-mode', dark); toggle.textContent = dark ? '☾' : '☼'; toggle.setAttribute('aria-pressed', String(dark)); };
  toggle.addEventListener('click', () => { dark = !dark; try { localStorage.setItem('foodrescue-theme', dark ? 'dark' : 'light'); } catch (_) {} applyTheme(); });
  applyTheme();
});
