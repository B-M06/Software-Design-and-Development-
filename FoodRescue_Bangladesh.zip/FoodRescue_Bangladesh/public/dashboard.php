<?php
require_once __DIR__ . '/../app/layout.php';
$u=require_login(); $pdo=db();
$counts=['food'=>0,'requests'=>0,'demand'=>0,'deliveries'=>0];
try {
 if (in_array($u['role'],['restaurant','event_organizer'],true)) {
  $q=$pdo->prepare("SELECT COUNT(*) FROM surplus_food WHERE restaurant_id=?"); $q->execute([$u['id']]); $counts['food']=(int)$q->fetchColumn();
  $q=$pdo->prepare("SELECT COUNT(*) FROM donation_requests dr JOIN surplus_food sf ON sf.id=dr.surplus_food_id WHERE sf.restaurant_id=? AND dr.status='requested'"); $q->execute([$u['id']]); $counts['requests']=(int)$q->fetchColumn();
 } elseif ($u['role']==='ngo' || $u['role']==='demand_reporter') {
  $q=$pdo->prepare("SELECT COUNT(*) FROM demand_requests WHERE created_by=?"); $q->execute([$u['id']]); $counts['demand']=(int)$q->fetchColumn();
  $q=$pdo->prepare("SELECT COUNT(*) FROM donation_requests WHERE requested_by=?"); $q->execute([$u['id']]); $counts['requests']=(int)$q->fetchColumn();
 } elseif ($u['role']==='volunteer') {
  $q=$pdo->prepare("SELECT COUNT(*) FROM deliveries WHERE volunteer_id=? AND status NOT IN ('completed','cancelled')"); $q->execute([$u['id']]); $counts['deliveries']=(int)$q->fetchColumn();
 } elseif ($u['role']==='admin') {
  $counts['food']=(int)$pdo->query("SELECT COUNT(*) FROM surplus_food")->fetchColumn();
  $counts['requests']=(int)$pdo->query("SELECT COUNT(*) FROM users WHERE verification_status='pending'")->fetchColumn();
  $counts['demand']=(int)$pdo->query("SELECT COUNT(*) FROM demand_requests")->fetchColumn();
  $counts['deliveries']=(int)$pdo->query("SELECT COUNT(*) FROM deliveries")->fetchColumn();
 }
} catch(Throwable $e) {}
page_header('Dashboard');
?>
<div class="dashboard-heading"><div><div class="eyebrow"><?= e(strtoupper(str_replace('_',' ',$u['role']))) ?> WORKSPACE</div><h1>Welcome, <?= e($u['name']) ?> <span class="wave">✳</span></h1><p class="muted">Here’s your FoodRescue activity at a glance.</p></div><div><?= status_badge($u['verification_status']) ?></div></div>
<?php if($u['verification_status']!=='verified' && $u['role']!=='admin'): ?><div class="alert warning"><strong>Account verification pending.</strong> Some actions may be restricted until an administrator verifies your account.</div><?php endif; ?>
<div class="dashboard-stats">
<?php if(in_array($u['role'],['restaurant','event_organizer','admin'],true)): ?><div class="stat-card"><div class="stat-label">Food listings</div><div class="stat-number"><?= number_format($counts['food']) ?></div><a href="<?= e(url(in_array($u['role'],['restaurant','event_organizer'],true)?'my_food.php':'food.php')) ?>">View listings →</a></div><?php endif; ?>
<?php if(in_array($u['role'],['restaurant','event_organizer','ngo','demand_reporter','admin'],true)): ?><div class="stat-card"><div class="stat-label"><?= $u['role']==='admin'?'Pending verifications':'Donation requests' ?></div><div class="stat-number"><?= number_format($counts['requests']) ?></div><a href="<?= e(url('requests.php')) ?>">Open requests →</a></div><?php endif; ?>
<?php if(in_array($u['role'],['ngo','demand_reporter','admin'],true)): ?><div class="stat-card"><div class="stat-label">Demand requests</div><div class="stat-number"><?= number_format($counts['demand']) ?></div><a href="<?= e(url('demand.php')) ?>">View demand →</a></div><?php endif; ?>
<?php if(in_array($u['role'],['volunteer','admin'],true)): ?><div class="stat-card"><div class="stat-label"><?= $u['role']==='admin'?'Delivery records':'My active deliveries' ?></div><div class="stat-number"><?= number_format($counts['deliveries']) ?></div><a href="<?= e(url('deliveries.php')) ?>">Track deliveries →</a></div><?php endif; ?>
</div>
<section class="section section-tight"><div class="section-heading"><div><div class="eyebrow">QUICK ACTIONS</div><h2>What would you like to do?</h2></div></div><div class="quick-grid">
<?php if(in_array($u['role'],['restaurant','event_organizer','admin'],true)): ?><a class="quick-card" href="<?= e(url('food_create.php')) ?>"><span>＋</span><b><?= $u['role']==='event_organizer'?'Donate event food':'Post surplus food' ?></b><small>List safe food for rescue</small></a><?php endif; ?>
<?php if(in_array($u['role'],['ngo','demand_reporter','admin'],true)): ?><a class="quick-card" href="<?= e(url('demand_create.php')) ?>"><span>⌁</span><b>Report food demand</b><small>Share an area's food needs</small></a><?php endif; ?>
<?php if(in_array($u['role'],['ngo','demand_reporter','admin'],true)): ?><a class="quick-card" href="<?= e(url('food.php')) ?>"><span>♡</span><b>Find available food</b><small>Browse safe surplus listings</small></a><a class="quick-card" href="<?= e(url('matches.php')) ?>"><span>⌖</span><b>Smart matches</b><small>Rank safe food by priority and area</small></a><?php endif; ?><a class="quick-card" href="<?= e(url('area_map.php')) ?>"><span>⌖</span><b>Area-wise map</b><small>Explore approved food locations</small></a>
<?php if(in_array($u['role'],['ngo','demand_reporter','admin'],true)): ?><a class="quick-card" href="<?= e(url('distribution.php')) ?>"><span>✓</span><b>Record distribution</b><small>Confirm meals and beneficiaries</small></a><?php endif; ?>
<?php if($u['role']==='volunteer'): ?><a class="quick-card" href="<?= e(url('volunteer.php')) ?>"><span>♧</span><b>Find rescue opportunities</b><small>Claim an unassigned delivery</small></a><?php endif; ?>
<?php if(in_array($u['role'],['volunteer','admin'],true)): ?><a class="quick-card" href="<?= e(url('deliveries.php')) ?>"><span>↗</span><b>Pickup & delivery</b><small>Update rescue progress</small></a><?php endif; ?>
<?php if($u['role']==='admin'): ?><a class="quick-card" href="<?= e(url('admin.php')) ?>"><span>✓</span><b>Admin control center</b><small>Verification and oversight</small></a><a class="quick-card" href="<?= e(url('admin_reviews.php')) ?>"><span>⚑</span><b>Safety & demand reviews</b><small>Validate safety and demand</small></a><?php endif; ?>
<a class="quick-card" href="<?= e(url('notifications.php')) ?>"><span>✉</span><b>Notifications</b><small>View important updates</small></a>
<a class="quick-card" href="<?= e(url('reports.php')) ?>"><span>▥</span><b>Impact reports</b><small>Review rescue activity</small></a>
</div></section>
<?php page_footer(); ?>
