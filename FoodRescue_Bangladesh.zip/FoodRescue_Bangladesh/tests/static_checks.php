<?php
declare(strict_types=1);
/** Database-independent source checks: php tests/static_checks.php */
$root = dirname(__DIR__);
require_once $root . '/app/helpers.php';
$checks = [
    'Distribution transaction locks request' => ['public/distribution.php', 'FOR UPDATE'],
    'Distribution duplicate prevention' => ['public/distribution.php', 'A distribution record already exists'],
    'Distribution sends notification' => ['public/distribution.php', 'Distribution recorded'],
    'Request acceptance rechecks safety approval' => ['public/requests.php', "fsc.result='safe'"],
    'Request acceptance reserves only available food' => ['public/requests.php', "status='reserved' WHERE id=? AND status='available'"],
    'Volunteer claim transaction lock' => ['public/volunteer.php', 'FOR UPDATE'],
    'Delivery status history saved' => ['public/deliveries.php', 'delivery_status_history'],
    'CSRF protection present on request workflow' => ['public/requests.php', 'verify_csrf();'],
    'Demand report stores structured area fields' => ['public/demand_create.php', 'district,upazila,ward'],
    'Demand map only shows verified active reports' => ['public/area_map.php', "status IN ('validated','partially_fulfilled')"],
    'Demand verification notifies reporter' => ['public/admin_reviews.php', 'Reporter has been notified.'],
    'NGO dashboard filters to verified demand' => ['public/demand.php', "status IN ('validated','partially_fulfilled','fulfilled')"],
    'Logout requires CSRF' => ['public/logout.php', 'verify_csrf();'],
    'Login is rate limited' => ['public/login.php', 'login_throttled'],
    'Session user re-validated each request' => ['app/helpers.php', 'Re-read the account every request'],
    'Session validation fails closed on DB error' => ['app/helpers.php', 'Never trust a stale session'],
    'Login throttling fails closed' => ['app/helpers.php', 'Login throttling: 5 failed attempts'],
    'Complaints can be submitted' => ['public/complaints.php', 'INSERT INTO complaints'],
    'Admin can review complaints' => ['public/complaints.php', 'complaint_'],
    'Password change available' => ['public/profile.php', 'password_verify($current'],
    'Food cards use images' => ['public/food.php', 'food_image_url'],
    'Food photo upload supported' => ['public/food_create.php', 'food_photo'],
    'Demo seeder populates realistic food photo paths' => ['scripts/seed_demo.php', 'assets/demo-food/chicken-biryani.jpg'],
    'Demo seeder includes 12 sample food listings' => ['scripts/seed_demo.php', "'Packed Lunch Boxes'"],
    'Seeder refreshes expired local demo deadlines' => ['scripts/seed_demo.php', '$refreshDemo->execute'],
    'Seeder repairs missing safe review on existing demo food' => ['scripts/seed_demo.php', '$findSafeCheck->execute'],
    'Local demo login accounts visible on localhost' => ['public/login.php', 'Local demo accounts (development only)'],
    'Food empty state explains how to seed demo data' => ['public/food.php', 'php scripts/seed_demo.php'],
    'Map empty state explains missing demo markers' => ['public/area_map.php', 'No food markers yet.'],
    'Admin user management' => ['public/admin_users.php', 'reset_password'],
    'Admin audit log viewer' => ['public/admin_logs.php', 'audit_logs'],
    'Verification document served to admins only' => ['public/admin_document.php', "require_role(['admin'])"],
    'Registration collects verification document' => ['public/register.php', 'verification_doc'],
    'Food listing edit re-queues safety review' => ['public/food_edit.php', "result='pending'"],
    'Demand edit limited to pending reports' => ['public/demand_edit.php', "status='pending'"],
    'Demand cancel available' => ['public/my_demand.php', "status='cancelled'"],
    'Donor can cancel own listing' => ['public/my_food.php', "status='cancelled'"],
    'Unicode length fallback available without mbstring' => ['app/helpers.php', 'function text_length(string $value): int'],
    'Banglish typing helper included' => ['public/assets/app.js', 'foodrescue-banglish-enabled'],
    'Banglish typing toggle present' => ['app/layout.php', 'id="banglishToggle"'],
    'Database uses utf8mb4 connection charset' => ['app/db.php', 'charset=utf8mb4'],
    'Baseline browser security headers configured' => ['config/config.php', "X-Content-Type-Options: nosniff"],
    'Banglish toggle handles disabled localStorage' => ['public/assets/app.js', 'Storage can be disabled'],
];
$failed = 0;
foreach ($checks as $label => [$file, $needle]) {
    $source = file_get_contents($root . '/' . $file);
    if ($source !== false && str_contains($source, $needle)) echo "PASS: {$label}\n";
    else { echo "FAIL: {$label}\n"; $failed++; }
}
if (text_length('বাংলা') !== 5) { echo "FAIL: Unicode length counts Bengali characters correctly\n"; $failed++; } else { echo "PASS: Unicode length counts Bengali characters correctly\n"; }
if ($failed) exit(1);
echo "\nAll database-independent source checks passed.\n";
